<?php 
    include('../../database/dbconnection.php');
    extract($_POST);
    date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
	$cur_date = date('Y-m-d');
    $cur_time = date('H:i:s A');

    
    $sql = "INSERT INTO `exp_payment_advice_cancellation`(`fin_yr`, `branch`, `pay_advice_id_fk`,
    `remark`,`pac_no`,
    `add_date`, `add_time`,`added_by`) VALUES ('$fin_yr',
    '$branch','$pay_advice_id_fk', '$remark' ,'$pac_no',
    '$cur_date','$cur_time','admin@gmail.com')";
     $res = mysqli_query($db,$sql) or die(mysqli_error($db));
      if($res)
      {

        $sno=$pac_no+1;
        $sql12 = "UPDATE mstr_data_series SET sr_no= '$sno' WHERE name='exp_pay_advice_cancel' ";
        $res = mysqli_query($db,$sql12);
          echo "1";
      }
      else
      {
          echo "0";
      }
 
?>
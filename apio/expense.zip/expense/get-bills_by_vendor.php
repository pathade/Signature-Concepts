<?php 
header('Content-Type: application/json'); 
$response = array();    
if($_SERVER['REQUEST_METHOD']=='GET')
{
  extract($_GET);
  include '../../database/dbconnection.php';
   $sql = "SELECT * FROM exp_bill_entry WHERE vendor_id_fk = '$vendor_id_fk' ";
    
   $data = array();
    $result1 = mysqli_query($db, $sql);
    if($result1)
    {
    $i=1;
    while($row=mysqli_fetch_assoc($result1))
    {
   
     $obj = array();
     $obj['start'] = $i++;
      $obj['vendor_name'] = $row['vendor_id_fk'];
      $obj['bill_no'] = $row['bill_no'];
      $obj['bill_date'] = $row['bill_date'];
      $obj['bill_amt'] = $row['actual_bal'];
      $obj['addition'] = '0';
      $obj['deduction'] = '0';
      $obj['final_payment'] = $row['actual_bal'];
      $obj['paid_amount'] = '0';
      
      array_push($response, $obj);
  }
}

  }
    echo json_encode($response);
  ?>
  